

#' Niche-models corrected barcoding identification.
#'
#' @description Species identification using both the barcoding and niche models.
#'
#' @param  ref.seq The reference dataset containing sample ID, taxon information, longitude and latitude and barcode sequences of each sample in class DNAbin.
#' @param  que.seq The query file containing sample ID, longitude and latitude and barcode sequences of each sample in class DNAbin.
#' @param  barcode.method A character string indicating which method will be used to train the model and/or infer species membership.
#'         One of these methods ("fuzzyId", "bpNewTraining", "Bayesian") should be specified.
#' @param  en.vir The global bioclimatic data from the "raster::getData" function in class RasterBrick.
#' @param  bak.vir Bioclimatic variables of random background points in class matrix.
#' @param  bio.variables The identifier of selected bioclimate variables in class integer.
#'         Default of c(1:19), representing the 19 commonly used bioclimate variables.
#'
#' @return A data frame of barcoding identification results for each query sample and their niche-based reliabilities.
#'
#' @keywords NicoB
#'
#' @export
#'
#' @import raster
#' @import maps
#' @import randomForest
#' @import BarcodingR
#'
#' @author Cai-qing YANG and Ai-bing ZHANG, CNU, Beijing, CHINA.
#' Emails: yangcq_ivy(at)163.com; zhangab2008(at)mail.cnu.edu.cn.
#'
#' @references Breiman, L. 2001. Random forests. Machine Learning 45(1): 5-32.
#' @references Liaw, A. and M. Wiener. 2002. Clasification and regression by randomForest. R News 2/3: 18-22.
#' @references Zhang, A.B, Hao, M.D., Yang,C.Q., Shi, Z.Y. (2016). BarcodingR:
#' an integrated R package for species identification using DNA barcodes. Methods in Ecology and Evolution.
#' https://doi.org/10.1111/2041-210X.12682.
#' @references Jin,Q., H.L. Han, X.M. Hu, X.H. Li,C.D. Zhu,S. Y. W. Ho, R. D. Ward, A.B. Zhang. (2013).
#' Quantifying Species Diversity with a DNA Barcoding-Based Method: Tibetan Moth Species (Noctuidae)
#' on the Qinghai-Tibetan Plateau. PloS One 8: e644.
#' @references Zhang, A. B., C. Muster, H.B. Liang, C.D. Zhu, R. Crozier, P. Wan, J. Feng, R. D. Ward.(2012).
#' A fuzzy-set-theory-based approach to analyse species membership in DNA barcoding. Molecular Ecology, 21(8):1848-63.
#' @references Zhang, A. B., D. S. Sikes, C. Muster, S. Q. Li. (2008). Inferring Species Membership using DNA sequences
#' with Back-propagation Neural Networks. Systematic Biology, 57(2):202-215.
#' @references Hijmans, R. J., S. E. Cameron, J. L. Parra, P. G. Jones and A. Jarvis. 2005.
#' Very high resolution interpolated climate surfaces for global land areas. International Journal of Climatology 25(15): 1965-1978.
#'
#' @note
#'
#'
#' @examples
#' \dontrun{
#' data(Ref)
#' data<-Ref
#' ref.seq=data[1:25,]
#' ref.seq
#' que.seq=data[26:30,];rownames(que.seq)<-gsub("\\,[A-Za-z0-9\\.\\-\\_]*\\,","\\,",rownames(que.seq))
#' que.seq
#'# Note: set "download=FALSE", if raster::getData() has been run once!
#' envir<-raster::getData("worldclim",download=TRUE,var="bio",
#' res=2.5,lon=lon,lat=lat) ## first run, download=true, second run, download=FALSE!
#' en.vir<-brick(envir)
#' back<-randomPoints(mask=en.vir,n=5000,ext=NULL,extf=1.1,
#' excludep=TRUE,prob=FALSE,cellnumbers=FALSE,tryf=3,
#' warn=2,lonlatCorrection=TRUE)
#' bak.vir<-extract(en.vir,back)
#'
#' NMCB<-NicoB(ref.seq,que.seq,barcode.method="Bayesian",en.vir,bak.vir,bio.variables=c(1:19))
#' NMCB
#' }

#library(raster)
#library(maps)
#library(randomForest)
#library(BarcodingR)
NicoB<-function(ref.seq,que.seq,barcode.method,en.vir,bak.vir,bio.variables=c(1:19)){
  ### subfunctions required:
  ### 1. BSI
  #library(BarcodingR)
  BSI<-function(ref, que, method = "bpNewTraining") {

    if (dim(que)[2] != dim(ref)[2])
      warning("sequences in ref and que are different in length!")

    digitize.DNA<-function(seqs){

      locus<-toupper(as.character(seqs))
      digitized.DNA<-locus
      digitized.DNA[digitized.DNA=="A"]<-0.1
      digitized.DNA[digitized.DNA=="T"]<-0.2
      digitized.DNA[digitized.DNA=="G"]<-0.3
      digitized.DNA[digitized.DNA=="C"]<-0.4
      digitized.DNA[digitized.DNA=="-"]<-0.5
      digitized.DNA[digitized.DNA=="N"]<-0.6
      digitized.DNA[digitized.DNA=="R"]<-0
      digitized.DNA[digitized.DNA=="Y"]<-0
      digitized.DNA[digitized.DNA=="M"]<-0
      digitized.DNA[digitized.DNA=="K"]<-0
      digitized.DNA[digitized.DNA=="S"]<-0
      digitized.DNA[digitized.DNA=="W"]<-0
      digitized.DNA[digitized.DNA=="H"]<-0
      digitized.DNA[digitized.DNA=="B"]<-0
      digitized.DNA[digitized.DNA=="V"]<-0
      digitized.DNA[digitized.DNA=="D"]<-0


      digitized.DNA<-as.numeric(digitized.DNA)
      digitized.DNA2<-array(digitized.DNA,dim=dim(seqs))
      dim(digitized.DNA2)

      return(digitized.DNA2)
    }
    eucl.dist.two.vect<-function(v1,v2){
      v1minusv2<-v1-v2
      squared.v1minusv2<-v1minusv2*v1minusv2
      out.sqrt<-sqrt(sum(squared.v1minusv2))
      return(out.sqrt)

    }### end of fucntion

    strings.equal<-function(str1,str2){ifelse(str1==str2,1,0)}

    ##############
    naiveBayes <- function(x, ...)
      UseMethod("naiveBayes")

    naiveBayes.default <- function(x, y, laplace = 0, ...) {
      call <- match.call()
      Yname <- deparse(substitute(y))
      x <- as.data.frame(x)

      ## estimation-function
      est <- function(var)
        if (is.numeric(var)) {
          cbind(tapply(var, y, mean, na.rm = TRUE),
                tapply(var, y, sd, na.rm = TRUE))
        } else {
          tab <- table(y, var)
          (tab + laplace) / (rowSums(tab) + laplace * nlevels(var))
        }

      ## create tables
      apriori <- table(y)
      tables <- lapply(x, est)

      ## fix dimname names
      for (i in 1:length(tables))
        names(dimnames(tables[[i]])) <- c(Yname, colnames(x)[i])
      names(dimnames(apriori)) <- Yname

      structure(list(apriori = apriori,
                     tables = tables,
                     levels = levels(y),
                     call   = call
      ),

      class = "naiveBayes"
      )
    }

    naiveBayes.formula <- function(formula, data, laplace = 0, ...,
                                   subset, na.action = na.pass) {
      call <- match.call()
      Yname <- as.character(formula[[2]])

      if (is.data.frame(data)) {
        ## handle formula
        m <- match.call(expand.dots = FALSE)
        m$... <- NULL
        m$laplace = NULL
        m$na.action <- na.action
        m[[1]] <- as.name("model.frame")
        m <- eval(m, parent.frame())
        Terms <- attr(m, "terms")
        if (any(attr(Terms, "order") > 1))
          stop("naiveBayes cannot handle interaction terms")
        Y <- model.extract(m, "response")
        X <- m[,-attr(Terms, "response"), drop = FALSE]

        return(naiveBayes(X, Y, laplace = laplace, ...))
      } else if (is.array(data)) {
        nam <- names(dimnames(data))
        ## Find Class dimension
        Yind <- which(nam == Yname)

        ## Create Variable index
        deps <- strsplit(as.character(formula)[3], ".[+].")[[1]]
        if (length(deps) == 1 && deps == ".")
          deps <- nam[-Yind]
        Vind <- which(nam %in% deps)

        ## create tables
        apriori <- margin.table(data, Yind)
        tables <- lapply(Vind,
                         function(i) (margin.table(data, c(Yind, i)) + laplace) /
                           (as.numeric(apriori) + laplace * dim(data)[i]))
        names(tables) <- nam[Vind]

        structure(list(apriori = apriori,
                       tables = tables,
                       levels = names(apriori),
                       call   = call
        ),

        class = "naiveBayes"
        )
      } else stop("naiveBayes formula interface handles data frames or arrays only")

    }


    print.naiveBayes <- function(x, ...) {
      cat("\nNaive Bayes Classifier for Discrete Predictors\n\n")
      cat("Call:\n")
      print(x$call)
      cat("\nA-priori probabilities:\n")
      print(x$apriori / sum(x$apriori))

      cat("\nConditional probabilities:\n")
      for (i in x$tables) {print(i); cat("\n")}

    }

    predict.naiveBayes <- function(object,
                                   newdata,
                                   type = c("class", "raw"),
                                   threshold = 0.001,
                                   eps = 0,
                                   ...) {
      type <- match.arg(type)
      newdata <- as.data.frame(newdata)
      attribs <- match(names(object$tables), names(newdata))
      isnumeric <- sapply(newdata, is.numeric)
      newdata <- data.matrix(newdata)
      L <- sapply(1:nrow(newdata), function(i) {
        ndata <- newdata[i, ]
        L <- log(object$apriori) + apply(log(sapply(seq_along(attribs),
                                                    function(v) {
                                                      nd <- ndata[attribs[v]]
                                                      if (is.na(nd)) rep(1, length(object$apriori)) else {
                                                        prob <- if (isnumeric[attribs[v]]) {
                                                          msd <- object$tables[[v]]
                                                          msd[, 2][msd[, 2] <= eps] <- threshold
                                                          dnorm(nd, msd[, 1], msd[, 2])
                                                        } else object$tables[[v]][, nd]
                                                        prob[prob <= eps] <- threshold
                                                        prob
                                                      }
                                                    })), 1, sum)
        if (type == "class")
          L
        else {
          sapply(L, function(lp) {
            1/sum(exp(L - lp))
          })
        }
      })
      if (type == "class")
        factor(object$levels[apply(L, 2, which.max)], levels = object$levels)
      else t(L)
    }



    ##############



    FMF<-function(xtheta12){
      ###
      xtheta12<-as.numeric(xtheta12)

      if (class(xtheta12)!="numeric" ||length(xtheta12)!=3)
        stop("input should be a numeric vector with length of 3!!!")

      x<-xtheta12[1]
      theta1<-xtheta12[2]
      theta2<-xtheta12[3]


      if (x<=theta1) FMF<-1
      if (x>theta1 && x<=(theta2+theta1)/2) FMF<-1-2*((x-theta1)/(theta2-theta1))^2
      if (x<=theta2 && x>(theta2+theta1)/2) FMF<-2*((x-theta2)/(theta2-theta1))^2
      if (x>=theta2) FMF<-0
      return(FMF)
    }



    sampleSpeNames<-attr(ref,"dimnames")[[1]]

    mpattern<-".+,"

    Spp<-gsub(mpattern,"",sampleSpeNames)


    bp<-function(ref1,sampleSpeNames2, method = "bpNewTraining",que1){


      if(method == "bpNewTraining"){

        ref1_tmp<-ref1[!is.na(ref1)]
        range1<-1./max(abs(ref1_tmp))
        n.hidden<-ceiling(log2(dim(ref1)[1]))
        nnet.trained <- nnet(ref1, sampleSpeNames2, size = n.hidden, rang = range1,
                             decay = 5e-5,
                             maxit = 1e+6,
                             abstol = 1.0e-8,
                             reltol = 1.0e-8,
                             MaxNWts = 20000)
        #decay = 5e-4, maxit = 1e+5,MaxNWts = 2000)

        spe.inferred0<-predict(nnet.trained, que1)
        spe.inferred<-spe.inferred0

        inferred<-apply(spe.inferred,1,FUN=which.max)
        inferred.prob<-apply(spe.inferred,1,FUN=max)

        colnames(spe.inferred)[inferred]

        output.identified<-data.frame(queIDs=queIDs,
                                      spe.Identified=colnames(spe.inferred)[inferred],
                                      bp.prob=inferred.prob)


        rownames(output.identified)<-NULL

        ############################################################
        ####### calculate model success rate using ref  start...
        ###########################################################
        spe.inferred0.ref<-predict(nnet.trained, ref1)
        spe.inferred.ref<-spe.inferred0.ref

        inferred.ref<-apply(spe.inferred.ref,1,FUN=which.max)
        inferred.prob.ref<-apply(spe.inferred.ref,1,FUN=max)

        p.ref<-colnames(spe.inferred.ref)[inferred.ref]


        spe.morph.Identified<-data.frame(Spp,p.ref)

        matches<-apply(spe.morph.Identified,2,strings.equal,str2=spe.morph.Identified[,2])


        matches<-colSums(matches,dims = 1)

        success.rates.ref<-matches[1]/matches[2]
        names(success.rates.ref)<-NULL

        ############################################################
        ####### calculate model success rate using ref the end.
        ###########################################################

        out.bp<-list(summary.model=summary(nnet.trained),###convergence=nnet.trained$convergence,
                     convergence=nnet.trained$convergence,
                     success.rates.ref=success.rates.ref,
                     output_identified=output.identified)


        fileName<-"bbsi_tmp"

        fileName<-paste(fileName,".RData",sep = "")
        save(nnet.trained,
             out.bp,
             success.rates.ref,

             file = fileName)

        output2.identified<-out.bp

      }
      if(method == "bpNewTrainingOnly"){



        ref1_tmp<-ref1[!is.na(ref1)]
        center.ref1<-apply(ref1,MARGIN=2,FUN=mean)

        range1<-1./max(abs(ref1_tmp))
        n.hidden<-ceiling(log2(dim(ref1)[1]))
        nnet.trained <- nnet(ref1, sampleSpeNames2, size = n.hidden, rang = range1,
                             decay = 5e-5,
                             maxit = 1e+6,
                             abstol = 1.0e-8,
                             reltol = 1.0e-8,
                             MaxNWts = 20000)

        ############################################################
        ####### calculate model success rate using ref  start...
        ###########################################################
        spe.inferred0.ref<-predict(nnet.trained, ref1)
        spe.inferred.ref<-spe.inferred0.ref

        inferred.ref<-apply(spe.inferred.ref,1,FUN=which.max)
        inferred.prob.ref<-apply(spe.inferred.ref,1,FUN=max)

        p.ref<-colnames(spe.inferred.ref)[inferred.ref]


        spe.morph.Identified<-data.frame(Spp,p.ref)

        matches<-apply(spe.morph.Identified,2,strings.equal,str2=spe.morph.Identified[,2])


        matches<-colSums(matches,dims = 1)

        success.rates.ref<-matches[1]/matches[2]
        names(success.rates.ref)<-NULL

        ############################################################
        ####### calculate model success rate using ref the end.
        ###########################################################

        fileName<-"bbsi_tmp"

        fileName<-paste(fileName,".RData",sep = "")
        save(nnet.trained,
             success.rates.ref,
             #center.ref1,
             file = fileName) ## #save(x, y, file = "xy.RData")

        output2.identified<-"just saved to file!"


      }###
      if(method == "bpUseTrained"){

        if(!file.exists("bbsi_tmp.RData"))
          stop("file bbsi_tmp.RData not found in current directory!
               you need to move the file into current directory or rebuild the model!
               ")


        load("bbsi_tmp.RData")
        queIDs<-attr(que,"dimnames")[[1]]



        spe.inferred0<-predict(nnet.trained, que1)
        spe.inferred<-spe.inferred0

        inferred<-apply(spe.inferred,1,FUN=which.max)
        inferred.prob<-apply(spe.inferred,1,FUN=max)

        colnames(spe.inferred)[inferred]

        output.identified<-data.frame(queIDs=queIDs,
                                      spe.Identified=colnames(spe.inferred)[inferred],
                                      bp.prob=inferred.prob)


        rownames(output.identified)<-NULL

        output2.identified<-list(summary.model=summary(nnet.trained),###convergence=nnet.trained$convergence,
                                 convergence=nnet.trained$convergence,
                                 success.rates.ref=success.rates.ref,
                                 output_identified=output.identified)



      }



      class(output2.identified) <- c("BarcodingR")

      return(output2.identified)



    }



    #############################



    fuzzyId<-function(ref1,Spp2,que1){

      knn1<-knn(ref1, que1, cl=Spp2, k = 1, l = 0, prob = FALSE, use.all = TRUE)

      spe.Identified<-as.character(knn1)



      FMFtheta12<-function(Ref){


        ### 2.1 dealing with input DNA data!
        ### 2.2 calculate species center vectors
        morph.spe<-gsub(".+,","",rownames(Ref))

        species.centers<-aggregate(Ref,by=list(morph.spe),FUN="mean")


        list.spe<-species.centers[,1]
        species.centers<-species.centers[,-1]

        ### 2.3  seek NN for PS (all species in this case!)
        ### 2.3.1.calculate pair distance of species centers
        units.dist<-dist(species.centers, method = "euclidean", diag = F, upper = T, p = 2)
        units.dist0<-units.dist
        units.dist<-as.matrix(units.dist) ### important!


        for (i in 1: nrow(units.dist)) {units.dist[i,i]<-NA}


        #####
        ### 2.4. look for elements (their indices) with minimal distance to each other
        index1<-numeric(length(unique(morph.spe)))
        index2<-index1
        min.dist<-index1


        for (i in 1:nrow(units.dist)){
          index1[i]<-i

          b<-which.min(units.dist[i,])

          if (length(b)==0)
          {index2[i]<-NA
          min.dist[i]<-NA}
          else {index2[i]<-b
          min.dist[i]<-min(units.dist[i,],na.rm=T)}
        }


        pairs<-rbind(index1,index2)
        pairs<-t(pairs)

        pairs<-subset(pairs,subset=!is.na(pairs[,2]))



        theta1.tmp<-numeric(length(unique(morph.spe)))


        Spp<-morph.spe

        uniSpeNames<-unique(Spp)



        f<-factor(Spp)


        #####
        ###################################
        ### popSize calculation
        ###################################
        popSize.PS<-as.numeric(table(Spp))


        ###################################
        ### theta1,2 calculation
        ###################################


        seqInOneSpe<-Ref[Spp %in% levels(f)[1],]

        ifelse(popSize.PS[1]==1,centroid.spe<-seqInOneSpe,centroid.spe<-apply(seqInOneSpe,2,mean)) ###
        ifelse(popSize.PS[1]==1,centroid.spe0<-seqInOneSpe,centroid.spe0<-apply(seqInOneSpe,2,mean)) ###  centroid.spe0 -

        length.sites<-length(centroid.spe)
        ifelse(popSize.PS[1]==1,intra.dist<-0,intra.dist<-apply(seqInOneSpe,1,eucl.dist.two.vect,v2=centroid.spe)) ### to the centroid
        ifelse(popSize.PS[1]==1,theta1.tmp[1]<-0,theta1.tmp[1]<-3*sd(intra.dist)) ### theta1 is sligthly different from

        ######



        for(i in 2:length(levels(f))){
          seqInOneSpe<-Ref[Spp %in% levels(f)[i],]
          ifelse(popSize.PS[i]==1,centroid.spe0<-seqInOneSpe,centroid.spe0<-apply(seqInOneSpe,2,mean))
          ifelse(popSize.PS[i]==1,centroid.spe<-c(centroid.spe,seqInOneSpe),centroid.spe<-c(centroid.spe,apply(seqInOneSpe,2,mean)))
          ifelse(popSize.PS[i]==1,intra.dist<-eucl.dist.two.vect(seqInOneSpe,centroid.spe0),intra.dist<-apply(seqInOneSpe,1,eucl.dist.two.vect,v2=centroid.spe0))
          ifelse(popSize.PS[i]==1,theta1.tmp[i]<-0,theta1.tmp[i]<-3*sd(intra.dist)) ### theta1 is sligthly different from

        }




        centroid.spe.matrix<-t(array(centroid.spe,dim=c(length.sites,length(centroid.spe)%/%length.sites)))


        ### 1.2 calculate theta2 for each pairt of species


        ###################

        codes<-centroid.spe.matrix



        theta12.all<-data.frame(list.spe=list.spe,PS=pairs[,1],NN=pairs[,2])


        theta2.tmp<-numeric(dim(pairs)[1])


        for (i in 1:dim(pairs)[1]){

          v1<-codes[pairs[i,1],]
          v2<-codes[pairs[i,2],]


          theta2.tmp[i]<-eucl.dist.two.vect(v1,v2)
        }


        theta12.all$theta1<-with(theta12.all,theta1.tmp)
        theta12.all$theta2<-with(theta12.all,theta2.tmp)

        theta12.all$popSize.PS<-with(theta12.all,popSize.PS)


        return(theta12.all)



      }
      FMF.theta12<-FMFtheta12(ref1)

      FMF.que<-numeric(dim(que1)[1])

      for(j in 1:dim(que1)[1]){
        seqInOneSpe<-ref1[grep(spe.Identified[j], rownames(ref1), value = FALSE,fixed = TRUE),]
        k<-match(x=spe.Identified[j], table=FMF.theta12$list.spe)

        ifelse(FMF.theta12$popSize.PS[k]==1,centroid.spe0<-seqInOneSpe,centroid.spe0<-apply(seqInOneSpe,2,mean))


        que2PS.dist<-eucl.dist.two.vect(que1[j,],centroid.spe0)

        xtheta12<-c(que2PS.dist,FMF.theta12$theta1[k],FMF.theta12$theta2[k])
        FMF.que[j]<-FMF(xtheta12)
      }

      #### calculate success.rates.ref

      knn1<-knn(ref1, ref1, cl=Spp2, k = 1, l = 0, prob = FALSE, use.all = TRUE)

      spe.Identified.ref<-as.character(knn1)



      spe.morph.Identified<-data.frame(Spp,spe.Identified.ref)

      matches<-apply(spe.morph.Identified,2,strings.equal,str2=spe.morph.Identified[,2])


      matches<-colSums(matches,dims = 1)

      success.rates.ref<-matches[1]/matches[2]
      names(success.rates.ref)<-NULL



      output.identified<-data.frame(queIDs=queIDs,
                                    spe.Identified=spe.Identified,
                                    FMF=FMF.que)

      out<-list(success.rates.ref=success.rates.ref,
                output_identified=output.identified)


      class(out) <- c("BarcodingR")

      return(out)

      ##################



    }



    Bayesian<-function(ref,Spp,que){

      rq<-rbind(ref,que)
      rq<-rq[,seg.sites(rq)]

      queIDs<-attr(que,"dimnames")[[1]]


      ref.constant.sites.removed<-rq[1:dim(ref)[1],]
      que.constant.sites.removed<-rq[-(1:dim(ref)[1]),]


      ref2<-as.character(ref.constant.sites.removed)
      ref2<-as.data.frame(ref2)
      que2<-as.character(que.constant.sites.removed)
      que2<-as.data.frame(que2)
      rq2<-rbind(ref2,que2)
      Spp<-c(Spp,queIDs)
      rq2$species<-as.factor(Spp)
      ref3<-rq2[1:dim(ref2)[1],]



      ref3$species<-with(ref3,as.factor(gsub(".+,","",sampleSpeNames)))


      que3<-rq2[-(1:dim(ref2)[1]),]
      del<-dim(que3)[2]
      que3<-que3[,-del]


      head(ref3);class(ref3);dim(ref3)

      rownames(ref3)<-1:dim(ref3)[1]

      Bayesian.trained <- naiveBayes(species ~ ., data = ref3)


      spe.inferred<-predict(Bayesian.trained, que3)
      spe.inferred.prob<-predict(Bayesian.trained, que3, type = "raw")

      Bayesian.prob<-apply(spe.inferred.prob,1,max)


      spe.inferred<-as.character(spe.inferred)



      output.identified<-data.frame(queIDs=queIDs,
                                    spe.Identified=spe.inferred,
                                    Bayesian.prob=Bayesian.prob)



      out<-list(output_identified=output.identified)


      class(out) <- c("BarcodingR")



      return(out)
    }

    method <- pmatch(method, c("bpNewTraining",
                               "bpNewTrainingOnly",
                               "bpUseTrained",
                               "fuzzyId",
                               "Bayesian",
                               "all"))
    if (is.na(method))
      stop("invalid method")
    if (method == -1)
      stop("ambiguous method")

    if (method == 1){  ### "bpNewTraining"
      sampleSpeNames<-attr(ref,"dimnames")[[1]]
      queIDs<-attr(que,"dimnames")[[1]]

      mpattern<-".+,"

      Spp<-gsub(mpattern,"",sampleSpeNames)
      Spp

      sampleSpeNames2<-class.ind(Spp)


      rq<-rbind(ref,que)
      rq<-rq[,seg.sites(rq)]

      ref1<-rq[1:dim(ref)[1],]
      que1<-rq[-(1:dim(ref)[1]),]

      ref1<-digitize.DNA(ref1)

      que1<-digitize.DNA(que1)

      out<-bp(ref1,sampleSpeNames2,method = "bpNewTraining",que1)

    }


    if (method == 2){  ###"bpNewTrainingOnly"
      sampleSpeNames<-attr(ref,"dimnames")[[1]]

      mpattern<-".+,"

      Spp<-gsub(mpattern,"",sampleSpeNames)
      Spp

      sampleSpeNames2<-class.ind(Spp)

      ref1<-digitize.DNA(ref)

      out<-bp(ref1,sampleSpeNames2,method = "bpNewTrainingOnly",que1)



    }



    if (method == 3){ ###"bpUseTrained"
      que1<-digitize.DNA(que)

      out<-bp(ref1,sampleSpeNames2,method = "bpUseTrained",que1)
    }
    if (method == 4){###  "fuzzyId"


      rq<-rbind(ref,que)
      rq<-rq[,seg.sites(rq)]

      ref1<-rq[1:dim(ref)[1],]
      que1<-rq[-(1:dim(ref)[1]),]

      ref1<-digitize.DNA(ref1)
      que1<-digitize.DNA(que1)


      Spp2<-as.factor(Spp)
      rownames(ref1)<-Spp
      queIDs<-attr(que,"dimnames")[[1]]
      rownames(que1)<-queIDs



      out<-fuzzyId(ref1,Spp2,que1)
    }



    if (method == 5)
      out<-Bayesian(ref,Spp,que)

    return(out)

  }
  # The end of BSI #

  ### 2. niche.Model.Build
  #library(randomForest)
  #library(raster)
  niche.Model.Build<-function(prese=NULL,absen=NULL,prese.env=NULL,absen.env=NULL,bak.vir=NULL,en.vir){
    search.For.Diff.Absen.From.Prese<-function(prese,absen){
      eucl.dist.two.vect<-function(v1,v2){
        v1minusv2<-v1-v2

        squared.v1minusv2<-v1minusv2*v1minusv2
        out.sqrt<-sqrt(sum(squared.v1minusv2))

        return(out.sqrt)
      }


      ### 0.1 conversion of data type, and remove na data points!
      prese<-na.omit(prese)
      absen<-na.omit(absen)

      prese<-as.matrix(prese)
      absen<-as.matrix(absen)

      # 1 find out the centre of prese, by the function mean
      prese<-apply(prese,MARGIN=2,as.numeric)
      group.mean.prese<-apply(prese, MARGIN=2, mean, na.rm = T)

      # 2.calculate distance of each point of presence data to the center

      dist2center.prese<-apply(prese,1,eucl.dist.two.vect,v2=group.mean.prese)
      #dist2center.prese

      # 3.calculate 95%CI of the distance
      ci95<-quantile(dist2center.prese,prob=c(0.025,0.975),na.rm = T)

      # 4.to calculate the distance of absence data to the center of presence data
      dist2center.absen<-apply(absen,1,eucl.dist.two.vect,v2=group.mean.prese)
      dist2center.absen

      # 5.to check if the distance of absence to the center is within the range of 95% CI
      within.CI95<-function(ci,x){
        if(x>=ci[1]&&x<=ci[2]) return(TRUE)
        else return (FALSE)
      }

      out2<-sapply(dist2center.absen, within.CI95,ci=ci95)
      out2
      return(out2)

    }

    if (is.null(prese)==TRUE && is.null(prese.env)==FALSE){
      present.env0<-prese.env
    }else{
      if (!is.data.frame(prese)|dim(prese)[2]!=3){
        stop ("The present data must be a dataframe with three columns (species name, lon, lat)!\n")
      }else{
        if (is.null(prese.env)==TRUE){
          present.env0<-extract(en.vir,prese[,2:3])
        }else{
          present.env0<-prese.env
        }
      }
    }

    if (is.null(absen)==TRUE && is.null(absen.env)==TRUE){
      outputNum=dim(present.env0)[1]*10

      if (is.null(back)==TRUE){
        back<-randomPoints(mask=en.vir,n=outputNum*2,ext=NULL,extf=1.1,excludep=TRUE,prob=FALSE,cellnumbers=FALSE,tryf=3,warn=2,lonlatCorrection=TRUE)
        bak.vir<-extract(en.vir,back)
        bak0<-bak.vir[,colnames(bak.vir) %in% colnames(present.env0)]

        diff.absen.from.prese<-search.For.Diff.Absen.From.Prese(present.env0,bak0)
        diff<-bak0[which(diff.absen.from.prese==FALSE),]

        samp<-sample(dim(diff)[1],size=outputNum)
        absent.env0<-diff[samp,]
      }else{
        #bak.vir<-back
        bak0<-bak.vir[,colnames(bak.vir) %in% colnames(present.env0)]

        if (dim(back)[1] < outputNum*2){
          more<-outputNum*2-dim(back)[1]
          more.back<-randomPoints(mask=en.vir,n=more,ext=NULL,extf=1.1,excludep=TRUE,prob=FALSE,cellnumbers=FALSE,tryf=3,warn=2,lonlatCorrection=TRUE)
          more.bak.vir<-extract(en.vir,more.back)
          more.bak0<-more.bak.vir[,colnames(more.bak.vir) %in% colnames(present.env0)]
          bak0<-rbind(bak0,more.bak0)
        }

        diff.absen.from.prese<-search.For.Diff.Absen.From.Prese(present.env0,bak0)
        diff<-bak0[which(diff.absen.from.prese==FALSE),]

        if (dim(diff)[1] < outputNum){
          absent.env0<-diff
        }else{
          samp<-sample(dim(diff)[1],size=outputNum)
          absent.env0<-diff[samp,]
        }
      }
    }else{
      if (is.null(absen.env)==TRUE){
        absent.env0<-extract(en.vir,absen)
      }else{
        absent.env0<-absen.env
      }
    }

    present.env<-cbind(Count=1,present.env0)
    present.env<-apply(present.env,FUN=as.numeric,MARGIN=2)
    absent.env<-cbind(Count=0,absent.env0)
    absent.env<-apply(absent.env,FUN=as.numeric,MARGIN=2)

    Data<-as.data.frame(rbind(present.env,absent.env))
    Data$Count=as.factor(Data$Count)
    RF<-randomForest(Count ~., Data, ntree=500, importance=TRUE, na.action=na.roughfix)
    return(RF)
  }
  # The end of niche.Model.Build #




  ref.infor<-extractSpeInfo(rownames(ref.seq))
  que.infor<-extractSpeInfo(rownames(que.seq))

  ### Bioclimate variables ####
  ref.unique<-unique(ref.infor$species)
  ref.nspe<-length(ref.unique)

  samp.env<-data.frame()
  for (su in 1:ref.nspe){
    prese.lonlat<-ref.infor[ref.infor$species %in% ref.unique[su],]
    present.points<-pseudo.present.points(prese.lonlat[,3:5],5,5,2)
    present.points

    prese.env<-extract(en.vir,present.points[,2:3])
    if (!all(is.na(prese.env[,1])==FALSE)){
      nonerr.env<-prese.env[-which(is.na(prese.env[,1])==TRUE),]
      if (is.null(dim(nonerr.env))==TRUE){
        prese.env<-t(as.data.frame(nonerr.env))
        row.names(prese.env)=NULL
      }else if (dim(nonerr.env)[1]==0){
        stop ("Please check the coordinate of ",ref.unique[su]," !\n")
      }else{
        prese.env<-nonerr.env
      }
    }

    spe.env<-cbind(Species=as.character(ref.unique[su]),prese.env)
    samp.env<-rbind(samp.env,spe.env)

    cat("Extracting:",su,"/",ref.nspe,as.character(ref.unique[su]),"\n")
  }
  samp.env[,2:20]<-apply(samp.env[,2:20],FUN=as.integer,MARGIN=2)
  head(samp.env);dim(samp.env)

  ### Species identification ####
  row.names(ref.seq)<-gsub("\\,[0-9\\.\\ \\-]*$","",rownames(ref.seq));ref.seq
  row.names(que.seq)<-gsub("\\,[0-9\\.\\ \\-]*$","",rownames(que.seq));que.seq

  if (barcode.method == "Bayesian"){
    bsi<-BSI(ref.seq,que.seq,method="Bayesian")
    BSI.out<-data.frame(queryID = rownames(que.seq),
                        species.identified = bsi$output_identified$spe.Identified,
                        barcoding.based.prob = bsi$output_identified$Bayesian.prob)
    BSI.out
  }else if (barcode.method == "fuzzyId"){
    bsi<-BSI(ref.seq,que.seq,method="fuzzyId")
    BSI.out<-data.frame(queryID = rownames(que.seq),
                        species.identified = bsi$output_identified$spe.Identified,
                        barcoding.based.prob = bsi$output_identified$FMF)
    BSI.out
  }else if (barcode.method == "bpNewTraining"){
    bsi<-BSI(ref.seq,que.seq,method="bpNewTraining")
    BSI.out<-data.frame(queryID = rownames(que.seq),
                        species.identified = bsi$output_identified$spe.Identified,
                        barcoding.based.prob = bsi$output_identified$bp.prob)
    BSI.out
  }

  spe.identified<-as.character(BSI.out$species.identified)
  spe.identified.uniq<-unique(spe.identified);length(spe.identified.uniq)

  ### Niche selection ####
  eff.samp.env<-samp.env[,c(1,bio.variables+1)]

  # (1) Niche modeling and self-inquery of ref
  spe.niche<-list()
  niche.ref.prob<-list()

  for (siu in 1:length(spe.identified.uniq)){
    prese.env<-eff.samp.env[gsub(".+,","",eff.samp.env[,1]) %in% spe.identified.uniq[siu],-1]
    prese.env<-na.omit(prese.env)
    if (dim(prese.env)[1]==1){ prese.env<-rbind(prese.env,prese.env) }

    RF<-niche.Model.Build(prese=NULL,absen=NULL,prese.env=prese.env,absen.env=NULL,bak.vir=bak.vir,en.vir=en.vir)
    spe.niche[[siu]]<-RF

    spe.var<-apply(prese.env,FUN=as.numeric,MARGIN=2)
    ref.HSI<-predict(RF,spe.var,type="prob")
    niche.ref.prob[[siu]]<-min(ref.HSI[,2])

    cat("Modeling:",siu,"/",length(spe.identified.uniq),"\n")
  }
  spe.niche
  niche.ref.prob

  # (2) Predect of query samples and calculate NicoB.prob
  que.vari<-extract(en.vir,que.infor[,4:5])
  if (dim(que.vari)[1] == 1){
    que.vari<-que.vari[,colnames(que.vari) %in% colnames(eff.samp.env)]
    que.vari<-t(as.data.frame(que.vari))
  }else{
    que.vari<-apply(que.vari,MARGIN=2,as.integer)
    que.vari<-que.vari[,colnames(que.vari) %in% colnames(eff.samp.env)]
  }

  result<-data.frame()
  for(n in 1:dim(que.vari)[1]){
    queID<-as.character(que.infor[n,2])
    potential.spe<-as.character(BSI.out[grep(queID,BSI.out$queryID),]$species.identified)
    spe.index<-grep(paste(potential.spe,"$",sep=""),spe.identified.uniq,fixed=F)
    model<-spe.niche[[spe.index]]

    que.niche<-t(as.matrix(que.vari[n,]))
    if (all(is.na(que.niche)) == TRUE){
      stop ("Please check the coordinate of ",queID," !\n")
    }else{
      que.HSI<-predict(model,que.niche,type="prob")
      que.prob<-que.HSI[,2]
    }

    # Calculation of probability
    ref.prob<-niche.ref.prob[[spe.index]]
    CF=que.prob/ref.prob
    barcode.prob<-BSI.out[grep(queID,BSI.out$queryID),]$barcoding.based.prob
    final.prob=barcode.prob*CF
    if (final.prob > 1){ final.prob=1 }

    res0<-cbind(barcode.prob,ref.prob,que.prob,CF,final.prob)
    res0<-cbind(as.character(BSI.out[grep(queID,BSI.out$queryID),]$queryID),
                potential.spe,round(res0,4))
    result<-rbind(result,res0)
  }
  colnames(result)<-c("queID","potential.spe","barcode.prob","niche.ref.prob","niche.que.prob","CF","NicoB.prob")
  result<-as.data.frame(result)

  return(result)
}

# The end of NicoB #


