

#' Generation of pseudo absence points for niche model building
#'
#' @description Randomly generates pseudo points outside the 95 percentage confidence intervals (CI) of
#' the ecological space of the presence data when there is no absence data for building a niche model.
#'
#' @param  data A data frame containing longitudes and latitudes of a single species in class data.frame.
#' @param  en.vir The global bioclimatic data from the "raster::getData" function in class RasterBrick.
#' @param  outputNum The expected number of points.
#'
#' @return A data frame of simulated pseudo points.
#'         A data frame of bioclimatic variables for these pseudo points.
#'
#' @keywords pseudo.absent.points
#'
#' @export
#'
#' @import raster
#' @import maps
#' @import dismo
#'
#' @author Cai-qing YANG, Cong JIANG, and Ai-bing ZHANG, CNU, Beijing, CHINA.
#' Emails: yangcq_ivy(at)163.com; zhangab2008(at)mail.cnu.edu.cn.
#'
#' @references
#'
#' @note
#'
#' @examples
#' \dontrun{
#' data<-data.frame(species=rep("Acosmeryx anceus",3),
#' Lon=c(145.380,145.270,135.461),
#' Lat=c(-16.4800,-5.2500,-16.0810))
#' # Note: set "download=FALSE", if raster::getData() has been run once!
#' envir<-raster::getData("worldclim",download=TRUE,var="bio",
#' res=2.5,lon=lon,lat=lat)
#' en.vir<-brick(envir)
#'
#' absent.points<-pseudo.absent.points(data,en.vir,outputNum=100)
#' head(absent.points$lonlat)
#' head(absent.points$envir)
#' }


#library(dismo)
#library(raster)
#library(maps)
pseudo.absent.points<-function(data,en.vir,outputNum=500){
  if (!is.data.frame(data)|dim(data)[2]!=3){
    stop ("The input data must be a dataframe with three columns (species name, lon, lat)!\n")
  }else{
    pseudo.absent<-list()

    back<-randomPoints(mask=en.vir,n=outputNum*2,ext=NULL,extf=1.1,excludep=TRUE,prob=FALSE,cellnumbers=FALSE,tryf=3,warn=2,lonlatCorrection=TRUE)
    absen<-extract(en.vir,back)
    prese<-extract(en.vir,data[,2:3])
    search.For.Diff.Absen.From.Prese<-function(prese,absen){
      ### 0.0 functions required:
      #euclidean.dist.two.vectors
      eucl.dist.two.vect<-function(v1,v2){
        v1minusv2<-v1-v2

        squared.v1minusv2<-v1minusv2*v1minusv2
        out.sqrt<-sqrt(sum(squared.v1minusv2))

        return(out.sqrt)
      }### end of fucntion


      ### 0.1 conversion of data type, and remove na data points!
      prese<-na.omit(prese)
      absen<-na.omit(absen)

      prese<-as.matrix(prese)
      absen<-as.matrix(absen)

      # 1 find out the centre of prese, by the function mean
      prese<-apply(prese,MARGIN=2,as.numeric) #factor2numeric
      group.mean.prese<-apply(prese, MARGIN=2, mean, na.rm = T)

      # 2.calculate distance of each point of presence data to the center

      dist2center.prese<-apply(prese,1,eucl.dist.two.vect,v2=group.mean.prese)
      #dist2center.prese

      # 3.calculate 95%CI of the distance
      ci95<-quantile(dist2center.prese,prob=c(0.025,0.975),na.rm = T)

      # 4.to calculate the distance of absence data to the center of presence data
      dist2center.absen<-apply(absen,1,eucl.dist.two.vect,v2=group.mean.prese)

      dist2center.absen
      # 5.to check if the distance of absence to the center is within the range of 95% CI
      within.CI95<-function(ci,x){
        if(x>=ci[1]&&x<=ci[2]) return(TRUE)
        else return (FALSE)
      }

      out2<-sapply(dist2center.absen, within.CI95,ci=ci95)
      out2
      return(out2)

    }
    diff.absen.from.prese<-search.For.Diff.Absen.From.Prese(prese,absen)
    diff.point<-back[which(diff.absen.from.prese==FALSE),]
    diff.env<-absen[which(diff.absen.from.prese==FALSE),]

    samp<-sample(dim(diff.point)[1],size=outputNum)
    pseudo.absent$lonlat<-diff.point[samp,]
    pseudo.absent$envir<-diff.env[samp,]

    map("world")
    points(pseudo.absent$lonlat,col="red",pch=1,cex=0.6)
    points(data[,2:3],col="blue",pch=19,cex=0.6)
    points(back[which(diff.absen.from.prese==TRUE),],col="blue",pch=1,cex=0.6)
    legend(x="bottom",inset=-0.12,
           col=c("blue","blue","red"),
           pch=c(19,1,1),
           legend=c("Present","Wrong absent","Absent"),
           horiz=T,
           xpd=T,
           bty="n")

    return(pseudo.absent)
  }
}

# The end of pseudo.absent.points #

