

#' Generation of pseudo present points for niche model building
#'
#' @description Randomly generates pseudo points around actual presence distribution sites
#' when the number of present points is inadequate for building a niche model.
#'
#' @param  data The longitude and latitude of a single species in class data.frame.
#' @param  minNum The allowed minimum number of points.
#' @param  outputNum The expected number of points.
#' @param  squareRange Range of points generated (How many degrees around the actual present points).
#'
#' @return A data frame containing actual present points and simulated pseudo points.
#'
#' @keywords pseudo.present.points
#'
#' @export
#'
#' @import raster
#' @import maps
#'
#' @author Cai-qing YANG and Ai-bing ZHANG, CNU, Beijing, CHINA.
#' Emails: yangcq_ivy(at)163.com; zhangab2008(at)mail.cnu.edu.cn.
#'
#' @references
#'
#' @note
#'
#' @examples
#' data<-data.frame(species=rep("Acosmeryx anceus",3),
#' Lon=c(145.380,145.270,135.461),
#' Lat=c(-16.4800,-5.2500,-16.0810))
#'
#' present.points<-pseudo.present.points(data,10,10,1)
#' present.points


#library(raster)
#library(maps)
pseudo.present.points<-function(data,minNum=20,outputNum=50,squareRange=1){
  if (!is.data.frame(data)|dim(data)[2]!=3){
    stop ("The input data must be a dataframe with three columns (species name, lon, lat)!\n")
  }else{
    lon=data[,2];lat=data[,3]

    if (dim(data)[1]>=minNum){
      return (data)
      #stop ("You've got enough data!\n")

    }else{
      #Give a square range for simulated coordinates
      if (dim(unique(data))[1]==1){
        minLon=lon-squareRange;maxLon=lon+squareRange
        minLat=lat-squareRange;maxLat=lat+squareRange
      }else{
        minLon=min(lon);maxLon=max(lon)
        minLat=min(lat);maxLat=max(lat)
        if (minLon<(-180)|maxLon>180|minLat<(-90)|maxLat>90){
          stop ("squareRange out of Range!")
        }
      }

      #Define empty matrices for storing data
      location<-matrix(NA,1,2)
      landPoint<-matrix()
      count<-0
      simNum=outputNum-dim(data)[1]

      while (count<simNum|nrow(landPoint)==0){
        simLon<-runif(floor(2*simNum),minLon,maxLon)
        simLat<-runif(floor(2*simNum),minLat,maxLat)
        simLL<-cbind(simLon,simLat)

        map.w<-map.where("world",x=simLL[,1],y=simLL[,2])
        if (all(is.na(map.w))==TRUE){
          envir<-raster::getData(name="worldclim",download=FALSE,var="bio",res=2.5)
          eFactors<-extract(envir,simLL);eFactors[,1]
          if (all(is.na(eFactors[,1]))==TRUE){
            return (data)
            warning ("The location of ",data[,1]," must be re-confirmed!\n")
            break
          }else{
            landPoint<-matrix(simLL[which(is.na(eFactors[,1])==FALSE),],ncol=2);landPoint
          }
        }else{
          landPoint<-matrix(simLL[which(is.na(map.w)==FALSE),],ncol=2);landPoint
        }

        count<-count+nrow(landPoint);count
        location<-rbind(location,landPoint);location
      }

      #Sampling from redundant points
      simFrame<-data.frame("Simulation",location)
      n<-sample(count,simNum);n
      finalFrame<-simFrame[n+1,]

      #final format
      names(finalFrame)<-c("species","Lon","Lat")
      rownames(finalFrame)<-NULL
      colnames(data)<-c("species","Lon","Lat")
      output<-rbind(data,finalFrame)

      map("world",xlim=c(min(output$Lon)-40,max(output$Lon)+40),ylim=c(min(output$Lat)-40,max(output$Lat)+40))
      points(data$Lon,data$Lat,col="blue",pch=19)
      points(output$Lon,output$Lat,col="blue",pch=1)
      legend(x="bottom",inset=-0.12,
             col=c("blue","blue"),
             pch=c(19,1),
             legend=c("Present","Simulated"),
             horiz=T,
             xpd=T,
             bty="n")

      return (output)
    }
  }
}

# The end of pseudo.present.points #

