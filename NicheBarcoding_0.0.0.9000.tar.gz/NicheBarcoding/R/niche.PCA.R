

#' Principal component analysis of ecological niche among unknown species and the potential species to which they may belong
#'
#' @description Determine whether unknown species belong to a known species through principal component analysis of their
#' ecological niches according to their distributional information.
#'
#' @param  ref.lonlat A data frame of coordinates of a known species.
#' @param  que.lonlat A data frame of coordinates of unknown species.
#' @param  en.vir The globle bioclimate data from "raster::getData" function in class RasterBrick.
#'
#' @return A list containing importance and loadings of the components.
#' @return A figure showing whether the query points (blue solid circles) are located in the 95 percentage confidence intervals of the niche space of reference species.
#'
#' @keywords niche.PCA
#'
#' @export
#'
#' @import raster
#'
#' @author Cai-qing YANG, CNU, Beijing, CHINA.
#' Emails: yangcq_ivy(at)163.com; zhangab2008(at)mail.cnu.edu.cn.
#'
#' @references
#'
#' @note
#'
#' @examples
#' \dontrun{
#' data<-data.frame(species=rep("Acosmeryx anceus",3),
#' Lon=c(145.380,145.270,135.461),
#' Lat=c(-16.4800,-5.2500,-16.0810))
#' simuSites<-pseudo.present.points(data,10,500,30)
#' ref.lonlat<-simuSites[1:10,]
#' que.lonlat<-simuSites[481:500,]
#' # Note: set "download=FALSE", if raster::getData() has been run once!
#' envir<-raster::getData("worldclim",download=TRUE,var="bio",res=2.5,lon=lon,lat=lat)
#' en.vir<-brick(envir)
#'
#' PCA.summary<-niche.PCA(ref.lonlat,que.lonlat,en.vir)
#' PCA.summary
#' }


#library(raster)
niche.PCA<-function(ref.lonlat,que.lonlat,en.vir){
  # ref.lonlat must be more than 19 rows!
  if (dim(ref.lonlat)[1] < 19){
    cat ("ref.lonlat must be more than 19 points!\n")
    cat ("Generating the pseudo present points ......\n")
    ref.lonlat<-pseudo.present.points(ref.lonlat,19,50,1)
  }

  # Extract the environment variables
  data.var<-extract(en.vir,ref.lonlat[,2:3])
  que.var<-extract(en.vir,que.lonlat[,2:3])

  # PCA analysis
  env.pr<-princomp(data.var,cor=TRUE)
  summary<-summary(env.pr,loadings=TRUE)

  # Calculate principal component according to loading coefficient
  data.pca1<-t(apply(data.var,FUN=function(x){sum(summary$loadings[1:19,1]*x)},MARGIN=1))
  data.pca1<-scale(data.pca1[1,],center=T,scale=T)
  data.pca2<-t(apply(data.var,FUN=function(x){sum(summary$loadings[1:19,2]*x)},MARGIN=1))
  data.pca2<-scale(data.pca2[1,],center=T,scale=T)
  que.pca1<-t(apply(que.var,FUN=function(x){sum(summary$loadings[1:19,1]*x)},MARGIN=1))
  que.pca1<-scale(que.pca1[1,],center=T,scale=T)
  que.pca2<-t(apply(que.var,FUN=function(x){sum(summary$loadings[1:19,2]*x)},MARGIN=1))
  que.pca2<-scale(que.pca2[1,],center=T,scale=T)

  # Show all ref points & que points
  par(mar=c(6,5,5,8))
  plot(x=data.pca1,y=data.pca2,
       xlab="PCA1",ylab="PCA2",
       main="PCA Analysis in Both Ref & Que")
  points(x=que.pca1,y=que.pca2,col="blue",pch=19)
  legend(x="right",inset=-0.3,
         col=c("black","blue"),
         pch=c(1,19),
         legend=c("Ref.points","Que.points"),
         horiz=F,
         xpd=T,
         bty="o")

  # Calculate the 95%CI & draw them as boundaries
  CI.pca1<-quantile(data.pca1,prob=c(0.025,0.975),na.rm=T)
  CI.pca2<-quantile(data.pca2,prob=c(0.025,0.975),na.rm=T)
  abline(v=CI.pca1[1],col="red",lty=2)
  text(x=CI.pca1[1],y=min(data.pca2),"2.5%",col="red")
  abline(v=CI.pca1[2],col="red",lty=2)
  text(x=CI.pca1[2],y=min(data.pca2),"97.5%",col="red")
  abline(h=CI.pca2[1],col="red",lty=2)
  text(x=min(data.pca1),y=CI.pca2[1],"2.5%",col="red")
  abline(h=CI.pca2[2],col="red",lty=2)
  text(x=min(data.pca1),y=CI.pca2[2],"97.5%",col="red")

  return(summary)
}

# The end of niche.PCA #


