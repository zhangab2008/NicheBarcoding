

#' Niche conservatism of a multispecies dataset.
#'
#' @description Calculate the K statistic of phylogenetic signals of ecological niche characters.
#'
#' @param  spe.env A data frame of ecological variables of species.
#' @param  tree The rooted phylogenetic tree of those species in class phylo.
#'
#' @return The K statistic of phylogenetic signal on top three principle components.
#'         The niche conservatism of the multispecies dataset.
#'
#' @keywords niche.conserv
#'
#' @export
#'
#' @import picante
#'
#' @author Cai-qing YANG and Ai-bing ZHANG, CNU, Beijing, CHINA.
#' Emails: yangcq_ivy(at)163.com; zhangab2008(at)cnu.edu.cn.
#'
#' @references Blomberg, S. P., and T. Garland, Jr. 2002. Tempo and mode in evolution: phylogenetic inertia, adaptation and comparative methods. Journal of Evolutionary Biology 15:899-910.
#' @references Blomberg, S. P., T. Garland, Jr., and A. R. Ives. 2003. Testing for phylogenetic signal in comparative data: behavioral traits are more labile. Evolution 57:717-745.
#'
#' @note
#'
#' @examples
#' data(Simulation)
#' spe.env<-Simulation$spe.env
#' tree<-Simulation$tree;plot(tree)
#'
#' NC<-niche.conserv(spe.env,tree)
#' NC


#library(picante)
niche.conserv<-function(spe.env,tree){
  if (is.rooted(tree) == FALSE){ stop ("The tree must be rooted!\n") }
  if (dim(spe.env)[1] != length(tree$tip.label)){ stop ("The spe.env is not equal to the number of tree.tips!\n") }
  if (all(sort(spe.env[,1]) == sort(tree$tip.label)) == FALSE){ stop ("The name of spe.env is different with the name of tree.tips!\n") }

  tree$edge.length[tree$edge.length<=0]<-1e-7
  tree<-multi2di(tree, random = TRUE)

  Kstat<-list()
  spe.env[,2:20]<-apply(as.matrix(spe.env[,2:20]),FUN=as.numeric,MARGIN=2)

  if (dim(spe.env)[1] < dim(spe.env)[2]-1){
    RF.model<-randomForest(Species ~., spe.env, ntree=500, importance=TRUE, na.action=na.roughfix)

    im<-importance(RF.model)[,c(dim(importance(RF.model))[2]-1,dim(importance(RF.model))[2])]
    md<-sort(im[,1],decreasing=T)
    if (max(md) == 0){ md<-sort(im[,2],decreasing=T) }

    variance.prop<-c()
    cumulative.prop<-c()
    md.cum=0
    for (m in 1:19){
      prop<-md[m]/sum(md)
      variance.prop<-c(variance.prop,prop)
      md.cum=md.cum+prop
      cumulative.prop<-c(cumulative.prop,md.cum)
    }
    RF.im<-rbind(md,variance.prop,cumulative.prop)
    rownames(RF.im)<-c("MD","Proportion of MDA","Cumulative Proportion")
    prop.var<-RF.im[2,]

    Kstat$result<-data.frame()
    Kstat$niche.conserved=0
    for (ps in 2:20){
      value<-as.numeric(spe.env[,ps])
      names(value)<-spe.env[,1];head(value)

      K<-phylosignal(value,tree)
      Kstat$result<-rbind(Kstat$result,K)

      stat<-K[,1]*prop.var[names(prop.var) %in% colnames(spe.env)[ps]]
      Kstat$niche.conserved=Kstat$niche.conserved+stat
    }
    Kstat$result[,-c(2:3)]
    Kstat$niche.conserved<-as.numeric(Kstat$niche.conserved)
    names(Kstat$niche.conserved)<-"K"

  }else{
    env.pr<-princomp(spe.env[,2:20],cor=TRUE)
    scores<-data.frame(env.pr$scores[,1:3]);head(scores)

    sdev.sum<-sum(summary(env.pr,loadings=F)$sdev^2)
    prop.var1<-summary(env.pr,loadings=F)$sdev[1]^2/sdev.sum
    prop.var2<-summary(env.pr,loadings=F)$sdev[2]^2/sdev.sum
    prop.var3<-summary(env.pr,loadings=F)$sdev[3]^2/sdev.sum

    PC1<-as.numeric(scores[,1])
    PC2<-as.numeric(scores[,2])
    PC3<-as.numeric(scores[,3])

    names(PC1)<-spe.env[,1];head(PC1)
    K1<-phylosignal(PC1,tree)
    names(PC2)<-spe.env[,1];head(PC2)
    K2<-phylosignal(PC2,tree)
    names(PC3)<-spe.env[,1];head(PC3)
    K3<-phylosignal(PC3,tree)

    Kstat$result<-rbind(K1,K2,K3)
    row.names(Kstat$result)<-c("PC1","PC2","PC3");Kstat$result[,-c(2:3)]

    Kstat$niche.conserved<-K1[1]*prop.var1+K2[1]*prop.var2+K3[1]*prop.var3
  }
  return (Kstat)
}



