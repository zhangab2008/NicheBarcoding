

#' Degree of niche overlap in a multispecies dataset.
#'
#' @description Calculate the proportion of species pairs with overlapping niches across the total number of species pairs.
#'
#' @param  ref The reference dataset containing sample ID, taxon information, longitude and latitude and barcode sequences of each sample in class DNAbin.
#' @param  en.vir The global bioclimatic data from the "raster::getData" function in class RasterBrick.
#'
#' @return A matrix of whether species pairs have overlapping niches
#'         (1 means this pair of species have overlapped in the range of 95 percentage confidence intervals with each other
#'          on at least one ecological variables, while 0 means not),
#'          and a numeric, the proportion representing the degree of niche overlap of the multispecies dataset.
#'
#' @keywords niche.overlap
#'
#' @export
#'
#' @import raster
#'
#' @author Cai-qing YANG and Ai-bing ZHANG, CNU, Beijing, CHINA.
#' Emails: yangcq_ivy(at)163.com; zhangab2008(at)mail.cnu.edu.cn.
#'
#' @references
#'
#' @note
#'
#' @examples
#' \dontrun{
#' data(Ref)
#' ref<-Ref
#'# Note: set "download=FALSE", if raster::getData() has been run once!
#' envir<-raster::getData("worldclim",download=TRUE,var="bio",
#' res=2.5,lon=lon,lat=lat)
#' en.vir<-brick(envir)
#'
#' n.overlap<-niche.overlap(ref,en.vir)
#' n.overlap$niche.overlap
#' }


#library(raster)
niche.overlap<-function(ref,en.vir){
  ref.infor<-extractSpeInfo(rownames(ref))
  ref.niche<-cbind(species=as.character(ref.infor[,3]),extract(en.vir,ref.infor[,4:5]))
  ref.niche<-as.data.frame(ref.niche)

  ref.unique<-unique(ref.infor$species)
  ref.nspe<-length(ref.unique)
  samp<-data.frame()
  for (ru in 1:ref.nspe){
    number<-length(which(ref.infor$species %in% ref.unique[ru]==TRUE))
    samp.num<-cbind(as.character(ref.unique[ru]),number)
    samp<-rbind(samp,samp.num)
  }
  colnames(samp)<-c("Species","SampleNumber");samp

  overlap<-list()
  overlap$matrix<-matrix(nrow=ref.nspe,ncol=ref.nspe)
  OL<-0;NO<-0

  for (spe1 in 1:(ref.nspe-1)){
    for (spe2 in (spe1+1):ref.nspe){
      p.value<-0
      for (bio in 2:20){
        sp1.vari<-as.numeric(as.character(ref.niche[ref.niche[,1] %in% ref.unique[spe1],bio]))
        sp2.vari<-as.numeric(as.character(ref.niche[ref.niche[,1] %in% ref.unique[spe2],bio]))
        if (is.na(sp1.vari)==TRUE && is.na(sp2.vari)==FALSE){
          err<-ref.infor[ref.infor[,3] %in% ref.unique[spe1],2]
          stop ("Please check the coordinate of",as.character(err),"!\n")
        }else if (is.na(sp1.vari)==FALSE && is.na(sp2.vari)==TRUE){
          err<-ref.infor[ref.infor[,3] %in% ref.unique[spe2],2]
          stop ("Please check the coordinate of",as.character(err),"!\n")
        }else if (is.na(sp1.vari)==TRUE && is.na(sp2.vari)==TRUE){
          err<-ref.infor[ref.infor[,3] %in% ref.unique[spe1],2]
          err<-ref.infor[ref.infor[,3] %in% ref.unique[spe2],2]
          stop ("Please check the coordinate of",as.character(err),"!\n")
        }else{
          q1<-quantile(sp1.vari,probs=c(0.025,0.975))
          q2<-quantile(sp2.vari,probs=c(0.025,0.975))
          if (min(q1) >= max(q2) | min(q2) >= max(q1)){
            p.value=0
          }else{
            p.value=1
            break
          }
        }
      }
      numb1<-as.numeric(as.character(samp[samp$Species %in% ref.unique[spe1],2]))
      numb2<-as.numeric(as.character(samp[samp$Species %in% ref.unique[spe2],2]))
      mean.numb<-(numb1+numb2)/2;mean.numb

      if (p.value == 1){
        overlap$matrix[spe2,spe1]<-1
        OL<-OL+mean.numb
      }else{
        overlap$matrix[spe2,spe1]<-0
        NO<-NO+mean.numb
      }
    }
    cat ("NicheOverlap:",spe1,"/",(ref.nspe-1),"\n")
  }
  rownames(overlap$matrix)<-as.character(ref.unique)
  colnames(overlap$matrix)<-as.character(ref.unique)
  overlap$niche.overlap<-round(OL/(OL+NO),4)
  return(overlap)
}

# The end of niche.overlap #

