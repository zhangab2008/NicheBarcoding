

#' Ecological niche modele building using randomForest classifier.
#'
#' @description  Builds a niche model for a given species according to its distributional data.
#'
#' @param  prese The longitude and latitude of the presence data of a species in class data.frame.
#'         (can be absent when providing prese.env parameter).
#' @param  absen The longitude and latitude of the absence data of a species in class data.frame.
#'         (can be absent when providing absen.env or back parameter).
#' @param  prese.env The bioclimatic variables of presence data in class data.frame
#'         (can be absent when providing prese parameter).
#' @param  absen.env The bioclimatic variables of absence data in class data.frame
#'         (can be absent when providing absen or back parameter).
#' @param  bak.vir Bioclimatic variables of random background points in class matrix
#'         (can be absent when providing absen or absen.env parameter).
#' @param  en.vir The globle bioclimate data from "raster::getData" function in class RasterBrick.
#'
#' @return  A trained niche model in class randomForest.
#'
#' @keywords niche.Model.Build
#'
#' @export
#'
#' @import randomForest
#' @import raster
#'
#' @author Cai-qing YANG and Ai-bing ZHANG, CNU, Beijing, CHINA.
#' Emails: yangcq_ivy(at)163.com; zhangab2008(at)cnu.edu.cn.
#'
#' @references Breiman, L. 2001. Random forests. Machine Learning 45(1): 5-32.
#' @references Liaw, A. and M. Wiener. 2002. Clasification and regression by randomForest. R News 2/3: 18-22.
#' @references Hijmans, R. J., S. E. Cameron, J. L. Parra, P. G. Jones and A. Jarvis. 2005. Very high resolution interpolated climate surfaces for global land areas. International Journal of Climatology 25(15): 1965-1978.
#'
#' @note
#'
#' @examples
#' \dontrun{
#' data<-data.frame(species=rep("Acosmeryx anceus",3),
#' Lon=c(145.380,145.270,135.461),
#' Lat=c(-16.4800,-5.2500,-16.0810))
#' present.points<-pseudo.present.points(data,10,10,1)
#'
#' # Note: set "download=FALSE", if raster::getData() has been run once!
#' envir<-raster::getData("worldclim",download=TRUE,var="bio",
#' res=2.5,lon=lon,lat=lat)
#' en.vir<-brick(envir)
#' back<-randomPoints(mask=en.vir,n=5000,ext=NULL,extf=1.1,
#' excludep=TRUE,prob=FALSE,cellnumbers=FALSE,tryf=3,
#' warn=2,lonlatCorrection=TRUE)
#' bak.vir<-extract(en.vir,back)
#'
#' RF.out<-niche.Model.Build(prese=present.points,bak.vir=bak.vir,en.vir=en.vir)
#' RF.out
#' #prese.env<-extract(en.vir,present.points[,2:3])
#'### RF.out2<-niche.Model.Build(prese=NULL,absen=NULL,prese.env=prese.env,
#'absen.env=NULL,bak.vir=bak.vir,en.vir=en.vir)
#'### RF.out2
#'}




#library(randomForest)
#library(raster)
niche.Model.Build<-function(prese=NULL,absen=NULL,prese.env=NULL,absen.env=NULL,bak.vir=NULL,en.vir){
  search.For.Diff.Absen.From.Prese<-function(prese,absen){
    eucl.dist.two.vect<-function(v1,v2){
      v1minusv2<-v1-v2

      squared.v1minusv2<-v1minusv2*v1minusv2
      out.sqrt<-sqrt(sum(squared.v1minusv2))

      return(out.sqrt)
    }


    ### 0.1 conversion of data type, and remove na data points!
    prese<-na.omit(prese)
    absen<-na.omit(absen)

    prese<-as.matrix(prese)
    absen<-as.matrix(absen)

    # 1 find out the centre of prese, by the function mean
    prese<-apply(prese,MARGIN=2,as.numeric)
    group.mean.prese<-apply(prese, MARGIN=2, mean, na.rm = T)

    # 2.calculate distance of each point of presence data to the center

    dist2center.prese<-apply(prese,1,eucl.dist.two.vect,v2=group.mean.prese)
    #dist2center.prese

    # 3.calculate 95%CI of the distance
    ci95<-quantile(dist2center.prese,prob=c(0.025,0.975),na.rm = T)

    # 4.to calculate the distance of absence data to the center of presence data
    dist2center.absen<-apply(absen,1,eucl.dist.two.vect,v2=group.mean.prese)
    dist2center.absen

    # 5.to check if the distance of absence to the center is within the range of 95% CI
    within.CI95<-function(ci,x){
      if(x>=ci[1]&&x<=ci[2]) return(TRUE)
      else return (FALSE)
    }

    out2<-sapply(dist2center.absen, within.CI95,ci=ci95)
    out2
    return(out2)

  }

  if (is.null(prese)==TRUE && is.null(prese.env)==FALSE){
    present.env0<-prese.env
  }else{
    if (!is.data.frame(prese)|dim(prese)[2]!=3){
      stop ("The present data must be a dataframe with three columns (species name, lon, lat)!\n")
    }else{
      if (is.null(prese.env)==TRUE){
        present.env0<-extract(en.vir,prese[,2:3])
      }else{
        present.env0<-prese.env
      }
    }
  }

  if (is.null(absen)==TRUE && is.null(absen.env)==TRUE){
    outputNum=dim(present.env0)[1]*10

    if (is.null(bak.vir)==TRUE){
      back<-randomPoints(mask=en.vir,n=outputNum*2,ext=NULL,extf=1.1,excludep=TRUE,prob=FALSE,cellnumbers=FALSE,tryf=3,warn=2,lonlatCorrection=TRUE)
      bak.vir<-extract(en.vir,back)
      bak0<-bak.vir[,colnames(bak.vir) %in% colnames(present.env0)]

      diff.absen.from.prese<-search.For.Diff.Absen.From.Prese(present.env0,bak0)
      diff<-bak0[which(diff.absen.from.prese==FALSE),]

      samp<-sample(dim(diff)[1],size=outputNum)
      absent.env0<-diff[samp,]
    }else{
      bak0<-bak.vir[,colnames(bak.vir) %in% colnames(present.env0)]

      if (dim(bak.vir)[1] < outputNum*2){
        more<-outputNum*2-dim(back)[1]
        more.back<-randomPoints(mask=en.vir,n=more,ext=NULL,extf=1.1,excludep=TRUE,prob=FALSE,cellnumbers=FALSE,tryf=3,warn=2,lonlatCorrection=TRUE)
        more.bak.vir<-extract(en.vir,more.back)
        more.bak0<-more.bak.vir[,colnames(more.bak.vir) %in% colnames(present.env0)]
        bak0<-rbind(bak0,more.bak0)
      }

      diff.absen.from.prese<-search.For.Diff.Absen.From.Prese(present.env0,bak0)
      diff<-bak0[which(diff.absen.from.prese==FALSE),]

      if (dim(diff)[1] < outputNum){
        absent.env0<-diff
      }else{
        samp<-sample(dim(diff)[1],size=outputNum)
        absent.env0<-diff[samp,]
      }
    }
  }else{
    if (is.null(absen.env)==TRUE){
      absent.env0<-extract(en.vir,absen)
    }else{
      absent.env0<-absen.env
    }
  }

  present.env<-cbind(Count=1,present.env0)
  present.env<-apply(present.env,FUN=as.numeric,MARGIN=2)
  absent.env<-cbind(Count=0,absent.env0)
  absent.env<-apply(absent.env,FUN=as.numeric,MARGIN=2)

  Data<-as.data.frame(rbind(present.env,absent.env))
  Data$Count=as.factor(Data$Count)
  RF<-randomForest(Count ~., Data, ntree=500, importance=TRUE, na.action=na.roughfix)
  return(RF)
}

# The end of niche.Model.Build #

