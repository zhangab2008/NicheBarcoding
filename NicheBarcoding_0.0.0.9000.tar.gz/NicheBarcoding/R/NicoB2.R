

#' Niche-model corrected for a given barcoding identification.
#'
#' @description Correct the barcoding identification result according to a given niche model.
#'
#' @param  ref.infor The reference dataset containing sample ID, taxon information and longitude and latitude of each sample in class data.frame.
#' @param  que.infor The query file containing sample ID and longitude and latitude of each sample in class data.frame.
#' @param  barcode.identi.result The previous results of species identification containing query ID, target species and credibility in class data.frame.
#' @param  en.vir The global bioclimatic data from the "raster::getData" function in class RasterBrick.
#' @param  bak.vir Bioclimatic variables of random background points in class matrix.
#' @param  bio.variables The identifier of selected bioclimatic variables in class integer.
#'         Default of c(1:19), representing the 19 commonly-used bioclimate variables.
#'
#' @return A data frame of barcoding identification results for each query sample and their niche-based reliabilities.
#'
#' @keywords NicoB2
#'
#' @export
#'
#' @import raster
#' @import maps
#' @import randomForest
#' @import BarcodingR
#'
#' @author Cai-qing YANG and Ai-bing ZHANG, CNU, Beijing, CHINA.
#' Emails: yangcq_ivy(at)163.com; zhangab2008(at)mail.cnu.edu.cn.
#'
#' @references Breiman, L. 2001. Random forests. Machine Learning 45(1): 5-32.
#' @references Liaw, A. and M. Wiener. 2002. Clasification and regression by randomForest. R News 2/3: 18-22.
#' @references Hijmans, R. J., S. E. Cameron, J. L. Parra, P. G. Jones and A. Jarvis. 2005. Very high resolution interpolated climate surfaces for global land areas. International Journal of Climatology 25(15): 1965-1978.
#'
#' @note
#'
#' @examples
#' \dontrun{
#' data(Identified_results)

#' # Note: set "download=FALSE", if raster::getData() has been run once!
#'  envir<-raster::getData("worldclim",download=TRUE,var="bio",
#'  res=2.5,lon=lon,lat=lat)
#'  en.vir<-brick(envir)
#' back<-randomPoints(mask=en.vir,n=5000,ext=NULL,extf=1.1,
#' excludep=TRUE,prob=FALSE,cellnumbers=FALSE,tryf=3,
#' warn=2,lonlatCorrection=TRUE)
#' bak.vir<-extract(en.vir,back)
#'
#' NMCB2<-NicoB2(ref.infor,que.infor,barcode.identi.result,en.vir,
#' bak.vir,bio.variables=c(1:19))
#' NMCB2
#' }


#library(raster)
#library(maps)
#library(randomForest)
#library(BarcodingR)
NicoB2<-function(ref.infor,que.infor,barcode.identi.result,en.vir,bak.vir,bio.variables=c(1:19)){

  ref.unique<-unique(ref.infor$species)
  ref.nspe<-length(ref.unique)

  samp.env<-data.frame()
  for (su in 1:ref.nspe){
    prese.lonlat<-ref.infor[ref.infor$species %in% ref.unique[su],]
    present.points<-pseudo.present.points(prese.lonlat[,3:5],5,5,2)
    present.points

    prese.env<-extract(en.vir,present.points[,2:3])
    if (!all(is.na(prese.env[,1])==FALSE)){
      nonerr.env<-prese.env[-which(is.na(prese.env[,1])==TRUE),]
      if (is.null(dim(nonerr.env))==TRUE){
        prese.env<-t(as.data.frame(nonerr.env))
        row.names(prese.env)=NULL
      }else if (dim(nonerr.env)[1]==0){
        stop ("Please check the coordinate of ",ref.unique[su]," !\n")
      }else{
        prese.env<-nonerr.env
      }
    }

    spe.env<-cbind(Species=as.character(ref.unique[su]),prese.env)
    samp.env<-rbind(samp.env,spe.env)

    cat("Extracting:",su,"/",ref.nspe,as.character(ref.unique[su]),"\n")
  }
  samp.env[,2:20]<-apply(samp.env[,2:20],FUN=as.integer,MARGIN=2)
  head(samp.env);dim(samp.env)

  spe.identified<-as.character(barcode.identi.result[,2])
  spe.identified.uniq<-unique(spe.identified);length(spe.identified.uniq)

  ### Niche selection ####
  eff.samp.env<-samp.env[,c(1,bio.variables+1)]

  # (1) Niche modeling and self-inquery of ref
  spe.niche<-list()
  niche.ref.prob<-list()

  for (siu in 1:length(spe.identified.uniq)){
    prese.env<-eff.samp.env[gsub(".+,","",eff.samp.env[,1]) %in% spe.identified.uniq[siu],-1]
    prese.env<-na.omit(prese.env)
    if (dim(prese.env)[1]==1){ prese.env<-rbind(prese.env,prese.env) }

    RF<-niche.Model.Build(prese=NULL,absen=NULL,prese.env=prese.env,absen.env=NULL,bak.vir=bak.vir,en.vir=en.vir)
    spe.niche[[siu]]<-RF

    spe.var<-apply(prese.env,FUN=as.numeric,MARGIN=2)
    ref.HSI<-predict(RF,spe.var,type="prob")
    niche.ref.prob[[siu]]<-min(ref.HSI[,2])

    cat("Modeling:",siu,"/",length(spe.identified.uniq),"\n")
  }
  spe.niche
  niche.ref.prob

  # (2) Predict query samples and calculate NicoB.prob
  que.vari<-extract(en.vir,que.infor[,4:5])
  if (dim(que.vari)[1] == 1){
    que.vari<-que.vari[,colnames(que.vari) %in% colnames(eff.samp.env)]
    que.vari<-t(as.data.frame(que.vari))
  }else{
    que.vari<-apply(que.vari,MARGIN=2,as.integer)
    que.vari<-que.vari[,colnames(que.vari) %in% colnames(eff.samp.env)]
  }

  result<-data.frame()
  for(n in 1:dim(que.vari)[1]){
    queID<-as.character(que.infor[n,2])
    potential.spe<-as.character(barcode.identi.result[grep(queID,barcode.identi.result[,1]),2])
    spe_in_ref<-as.character(ref.infor[grep(potential.spe,ref.infor$species),]$species)
    if (length(spe_in_ref) == 0){
      stop ("The identified species ",potential.spe," doesn't exist in ref.infor!\n")
    }

    spe.index<-grep(paste(potential.spe,"$",sep=""),spe.identified.uniq,fixed=F)  #the location of potential species in spe.identified.uniq
    model<-spe.niche[[spe.index]]  #the model of potential species

    que.niche<-t(as.matrix(que.vari[n,]))  #the variable of this
    if (all(is.na(que.niche)) == TRUE){
      stop ("Please check the coordinate of ",queID," !\n")
    }else{
      que.HSI<-predict(model,que.niche,type="prob")
      que.prob<-que.HSI[,2]
    }

    # Calculation of probability
    ref.prob<-niche.ref.prob[[spe.index]]
    CF=que.prob/ref.prob
    barcode.prob<-as.numeric(as.character(barcode.identi.result[grep(queID,barcode.identi.result[,1]),3]))
    final.prob=barcode.prob*CF
    if (final.prob > 1){ final.prob=1 }

    res0<-cbind(barcode.prob,ref.prob,que.prob,CF,final.prob)
    res0<-cbind(as.character(barcode.identi.result[grep(queID,barcode.identi.result[,1]),1]),
                potential.spe,round(res0,4))
    result<-rbind(result,res0)
  }
  colnames(result)<-c("queID","potantial.spe","barcode.prob","niche.ref.prob","niche.que.prob","CF","NicoB.prob")
  result<-as.data.frame(result)

  return(result)
}

# The end of NicoB2 #

